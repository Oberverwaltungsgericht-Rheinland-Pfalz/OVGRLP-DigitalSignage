/*! DigitalSignage.WebUi2.Manager - v2.1.0 - 25.11.2015 */
(function () {
  var app = angular.module('app');

  angular
    .module('app')
    .constant('appConfig', {
      apiUrl: '../WebApi',
      showPoweronButton: true,
      status: ['', 'Läuft', 'Abgeschlossen', 'Verschoben', 'Unterbrochen', 'Aufgehoben']
    });
})();